/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 lose lose.png 
 * Time-stamp: Thursday 04/02/2020, 06:41:33
 * 
 * Image Information
 * -----------------
 * lose.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSE_H
#define LOSE_H

extern const unsigned short lose[38400];
#define LOSE_SIZE 76800
#define LOSE_LENGTH 38400
#define LOSE_WIDTH 240
#define LOSE_HEIGHT 160

#endif

