/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=5x5 ballpic ballpic.png 
 * Time-stamp: Thursday 04/02/2020, 07:33:19
 * 
 * Image Information
 * -----------------
 * ballpic.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALLPIC_H
#define BALLPIC_H

extern const unsigned short ballpic[25];
#define BALLPIC_SIZE 50
#define BALLPIC_LENGTH 25
#define BALLPIC_WIDTH 5
#define BALLPIC_HEIGHT 5

#endif

