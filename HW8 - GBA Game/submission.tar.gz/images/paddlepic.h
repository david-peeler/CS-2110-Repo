/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=100x20 paddlepic paddlepic.png 
 * Time-stamp: Thursday 04/02/2020, 07:31:43
 * 
 * Image Information
 * -----------------
 * paddlepic.png 100@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PADDLEPIC_H
#define PADDLEPIC_H

extern const unsigned short paddlepic[2000];
#define PADDLEPIC_SIZE 4000
#define PADDLEPIC_LENGTH 2000
#define PADDLEPIC_WIDTH 100
#define PADDLEPIC_HEIGHT 20

#endif

