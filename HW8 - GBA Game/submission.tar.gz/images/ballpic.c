/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=5x5 ballpic ballpic.png 
 * Time-stamp: Thursday 04/02/2020, 07:33:19
 * 
 * Image Information
 * -----------------
 * ballpic.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "ballpic.h"

const unsigned short ballpic[25] =
{
	0x5add,0x107c,0x1cdc,0x673d,0x7fff,0x293b,0x0c5e,0x0c5e,0x107c,0x62fd,0x149c,0x107d,0x107d,0x0c5e,0x18bc,0x107c,
	0x0c5e,0x107d,0x0c5e,0x107c,0x463c,0x149c,0x107c,0x1cdc,0x5abd
};

