This game is pong, the 2D tennis game. Hit the ball back 5 times, and you win :) but if the ball goes past you, the game is over and you
lose :(.

Up - Move paddle up
Down - Move paddle down
Start - Start the game (at the main manu)
Select - Go back to main menu